CREATE DATABASE  IF NOT EXISTS `photolibrary` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci */;
USE `photolibrary`;
-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: photolibrary
-- ------------------------------------------------------
-- Server version	5.6.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `vw_machineview`
--

DROP TABLE IF EXISTS `vw_machineview`;
/*!50001 DROP VIEW IF EXISTS `vw_machineview`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_machineview` AS SELECT 
 1 AS `InspectionMachineId`,
 1 AS `Machine`,
 1 AS `Module`,
 1 AS `ViewId`,
 1 AS `View`,
 1 AS `FileType`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `vw_hgainfo_hgainspect`
--

DROP TABLE IF EXISTS `vw_hgainfo_hgainspect`;
/*!50001 DROP VIEW IF EXISTS `vw_hgainfo_hgainspect`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_hgainfo_hgainspect` AS SELECT 
 1 AS `HGAId`,
 1 AS `ProcessTrayId`,
 1 AS `Position`,
 1 AS `SerialNumber`,
 1 AS `SuspensionLotId`,
 1 AS `SliderLotId`,
 1 AS `PackId`,
 1 AS `Status`,
 1 AS `InspectionDataId`,
 1 AS `InspectionMachineId`,
 1 AS `Machine`,
 1 AS `Module`,
 1 AS `Datetime`,
 1 AS `StatusFromMachine`,
 1 AS `StatusFromOQA`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `vw_machineview`
--

/*!50001 DROP VIEW IF EXISTS `vw_machineview`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_machineview` AS select `him`.`InspectionMachineId` AS `InspectionMachineId`,`him`.`Machine` AS `Machine`,`him`.`Module` AS `Module`,`hiv`.`id` AS `ViewId`,`hiv`.`View` AS `View`,`hiv`.`FileType` AS `FileType` from (`hgainspectionmachine` `him` join `hgainspectionview` `hiv` on((`him`.`InspectionMachineId` = `hiv`.`InspectionMachineId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_hgainfo_hgainspect`
--

/*!50001 DROP VIEW IF EXISTS `vw_hgainfo_hgainspect`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_hgainfo_hgainspect` AS select `hgainfo`.`HGAId` AS `HGAId`,`hgainfo`.`ProcessTrayId` AS `ProcessTrayId`,`hgainfo`.`Position` AS `Position`,`hgainfo`.`SerialNumber` AS `SerialNumber`,`hgainfo`.`SuspensionLotId` AS `SuspensionLotId`,`hgainfo`.`SliderLotId` AS `SliderLotId`,`hgainfo`.`PackId` AS `PackId`,`hgainfo`.`Status` AS `Status`,`hgainspectdata`.`Id` AS `InspectionDataId`,`hgainspectdata`.`InspectionMachineId` AS `InspectionMachineId`,`hgainspectionmachine`.`Machine` AS `Machine`,`hgainspectionmachine`.`Module` AS `Module`,`hgainspectdata`.`Datetime` AS `Datetime`,`hgainspectdata`.`StatusFromMachine` AS `StatusFromMachine`,`hgainspectdata`.`StatusFromOQA` AS `StatusFromOQA` from ((`hgainformation` `hgainfo` left join `hgainspectiondata` `hgainspectdata` on((`hgainfo`.`HGAId` = `hgainspectdata`.`HGAId`))) left join `hgainspectionmachine` on((`hgainspectionmachine`.`InspectionMachineId` = `hgainspectdata`.`InspectionMachineId`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Dumping routines for database 'photolibrary'
--
/*!50003 DROP PROCEDURE IF EXISTS `ga` */;
ALTER DATABASE `photolibrary` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ga`(IN `fa` int)
    NO SQL
select * from hgainformation
where hgainformation.HGAId = fa ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `photolibrary` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `spLoadDefectHGA` */;
ALTER DATABASE `photolibrary` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spLoadDefectHGA`(IN `hgaIdparam` BIGINT(20))
BEGIN

SELECT hdata.Id, hgaoqa.ViewId, hview.View, hgaoqa.Defect, hgaoqa.PositionRatioX, hgaoqa.PositionRatioY
FROM hgainspectiondata hdata
	INNER JOIN hgaoqa on hdata.Id = hgaoqa.InspectionDataId
    INNER JOIN hgainspectionview hview on hview.Id = hgaoqa.ViewId
WHERE hdata.HGAId = hgaIdparam;
    
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `photolibrary` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `spSearchHGASerialNumber` */;
ALTER DATABASE `photolibrary` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSearchHGASerialNumber`(IN `hgaSNparam` VARCHAR(20))
BEGIN
	SELECT * FROM vw_hgainfo_hgainspect
    WHERE SerialNumber = hgaSNparam;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `photolibrary` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `spSearchPackId` */;
ALTER DATABASE `photolibrary` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSearchPackId`(IN `packIdparam` VARCHAR(20))
BEGIN
	SELECT * FROM vw_hgainfo_hgainspect
    WHERE PackId = packIdparam;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `photolibrary` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!50003 DROP PROCEDURE IF EXISTS `spSearchTrayId` */;
ALTER DATABASE `photolibrary` CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `spSearchTrayId`(IN `trayIdparam` VARCHAR(20))
BEGIN
	SELECT * FROM vw_hgainfo_hgainspect
    WHERE ProcessTrayId = trayIdparam;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
ALTER DATABASE `photolibrary` CHARACTER SET utf8 COLLATE utf8_unicode_ci ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-08 14:09:57
